select * from DETAIL_INFO;
select * from MEMBERS;
select * from CONTROL